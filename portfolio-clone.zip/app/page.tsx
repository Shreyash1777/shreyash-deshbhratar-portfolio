"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Github, Linkedin, ExternalLink, Mail } from "lucide-react"
import { motion } from "framer-motion"
import Typed from "typed.js"
import { ParticleBackground } from "@/components/particle-background"

export default function Home() {
  const [activeSection, setActiveSection] = useState("home")
  const typedElementRef = useRef(null)
  const homeRef = useRef<HTMLDivElement>(null)
  const aboutRef = useRef<HTMLDivElement>(null)
  const projectsRef = useRef<HTMLDivElement>(null)
  const skillsRef = useRef<HTMLDivElement>(null)
  const educationRef = useRef<HTMLDivElement>(null)
  const contactRef = useRef<HTMLDivElement>(null)

  // Typed.js initialization
  useEffect(() => {
    if (typedElementRef.current) {
      const typed = new Typed(typedElementRef.current, {
        strings: ["Software Engineer", "Full-Stack Developer", "Web Developer", "UI/UX Enthusiast"],
        typeSpeed: 50,
        backSpeed: 30,
        backDelay: 1500,
        loop: true,
        showCursor: true,
        cursorChar: "|",
      })

      return () => {
        typed.destroy()
      }
    }
  }, [])

  // Scroll tracking for active section
  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY + 200

      const sections = [
        { id: "home", ref: homeRef },
        { id: "about", ref: aboutRef },
        { id: "projects", ref: projectsRef },
        { id: "skills", ref: skillsRef },
        { id: "education", ref: educationRef },
        { id: "contact", ref: contactRef },
      ]

      for (let i = sections.length - 1; i >= 0; i--) {
        const section = sections[i]
        if (section.ref.current && section.ref.current.offsetTop <= scrollPosition) {
          setActiveSection(section.id)
          break
        }
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <main className="min-h-screen bg-black text-white overflow-hidden">
      {/* Portfolio Button */}
      <div className="fixed top-6 right-6 z-50">
        <Link
          href="#"
          className="bg-[#38bdf8]/20 text-[#38bdf8] px-4 py-2 rounded-full text-sm font-medium flex items-center gap-2 hover:bg-[#38bdf8]/30 transition-all duration-300 backdrop-blur-sm border border-[#38bdf8]/30"
        >
          <span>Open to Work</span>
        </Link>
      </div>

      {/* Particle Background */}
      <ParticleBackground />

      {/* Hero Section */}
      <section
        ref={homeRef}
        id="home"
        className="h-screen flex flex-col items-center justify-center px-4 text-center relative"
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-3xl mx-auto z-10"
        >
          {/* Header */}
          <h1 className="text-3xl text-gray-400 font-light mb-4">Hi I'm</h1>

          {/* Name with stylized font */}
          <div className="relative h-32 w-full mb-8">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, delay: 0.2 }}
              className="w-full h-full"
            >
              <Image src="/signature.png" alt="Vedantiu" fill priority className="object-contain" />
            </motion.div>
          </div>

          {/* Typed.js element */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-[#38bdf8] text-xl mb-8 h-8"
          >
            <span ref={typedElementRef}></span>
          </motion.div>

          {/* Resume Button */}
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.8, delay: 0.6 }}>
            <Link
              href="#"
              className="inline-block bg-[#38bdf8] text-[#0f172a] px-8 py-2 rounded-full text-sm font-medium mb-8 hover:bg-[#38bdf8]/90 transition-all duration-300 shadow-[0_0_15px_rgba(56,189,248,0.5)]"
            >
              Resume
            </Link>
          </motion.div>

          {/* Social Icons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="flex justify-center gap-6 mb-24"
          >
            <Link
              href="#"
              className="bg-[#1e293b] p-3 rounded-full hover:bg-[#38bdf8]/20 transition-all duration-300 border border-[#38bdf8]/30"
            >
              <Github className="w-5 h-5 text-[#38bdf8]" />
            </Link>
            <Link
              href="#"
              className="bg-[#1e293b] p-3 rounded-full hover:bg-[#38bdf8]/20 transition-all duration-300 border border-[#38bdf8]/30"
            >
              <Mail className="w-5 h-5 text-[#38bdf8]" />
            </Link>
            <Link
              href="#"
              className="bg-[#1e293b] p-3 rounded-full hover:bg-[#38bdf8]/20 transition-all duration-300 border border-[#38bdf8]/30"
            >
              <Linkedin className="w-5 h-5 text-[#38bdf8]" />
            </Link>
          </motion.div>
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1, y: [0, 10, 0] }}
          transition={{ duration: 1.5, delay: 1, repeat: Number.POSITIVE_INFINITY }}
          className="absolute bottom-10 left-1/2 transform -translate-x-1/2"
        >
          <div className="w-6 h-10 rounded-full border-2 border-[#38bdf8]/50 flex justify-center">
            <motion.div
              animate={{ y: [0, 15, 0] }}
              transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY }}
              className="w-1.5 h-1.5 bg-[#38bdf8] rounded-full mt-2"
            />
          </div>
        </motion.div>
      </section>

      {/* About Section */}
      <section ref={aboutRef} id="about" className="py-20 px-4 min-h-screen flex items-center bg-black">
        <div className="max-w-5xl mx-auto">
          <motion.h2
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-4xl font-bold mb-16 text-white relative inline-block"
          >
            About
            <span className="absolute -bottom-2 left-0 w-1/2 h-1 bg-[#38bdf8]"></span>
          </motion.h2>

          <div className="grid md:grid-cols-2 gap-10 items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="relative w-full h-80 md:h-96 rounded-lg overflow-hidden border-2 border-[#38bdf8]/20">
                <div className="absolute inset-0 bg-gradient-to-br from-[#38bdf8]/20 to-transparent z-10"></div>
                <Image
                  src="/placeholder.svg?height=400&width=400"
                  alt="Vedanti Udapure"
                  fill
                  className="object-cover"
                />
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="space-y-4"
            >
              <p className="text-gray-300 leading-relaxed">
                I'm Vedanti Udapure, a final-year CSE (Data Science) student at RCOEM, Nagpur, with hands-on experience
                in full-stack development. My passion for creating innovative solutions drives me to continuously learn
                and grow in the field of software engineering.
              </p>
              <p className="text-gray-300 leading-relaxed">
                I enjoy working with modern technologies and frameworks to build responsive and user-friendly
                applications. My goal is to create software that makes a positive impact and solves real-world problems.
              </p>
              <p className="text-gray-300 leading-relaxed">
                When I'm not coding, you can find me exploring new technologies, contributing to open-source projects,
                or enhancing my problem-solving skills through competitive programming.
              </p>

              <div className="pt-4">
                <Link
                  href="#contact"
                  className="inline-block bg-[#38bdf8]/20 text-[#38bdf8] px-6 py-2 rounded-full text-sm font-medium hover:bg-[#38bdf8]/30 transition-all duration-300 border border-[#38bdf8]/30"
                >
                  Get in Touch
                </Link>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section ref={projectsRef} id="projects" className="py-20 px-4 min-h-screen flex items-center bg-black">
        <div className="max-w-5xl mx-auto w-full">
          <motion.h2
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-4xl font-bold mb-16 text-white relative inline-block"
          >
            Projects
            <span className="absolute -bottom-2 left-0 w-1/2 h-1 bg-[#38bdf8]"></span>
          </motion.h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Portfolio Website",
                description: "Personal portfolio website built with React and Next.js",
                image: "/placeholder.svg?height=300&width=400",
                tech: ["React", "Next.js", "Tailwind CSS"],
                demo: "#",
                github: "#",
              },
              {
                title: "E-Commerce Platform",
                description: "Full-stack e-commerce application with payment integration",
                image: "/placeholder.svg?height=300&width=400",
                tech: ["React", "Node.js", "MongoDB", "Stripe"],
                demo: "#",
                github: "#",
              },
              {
                title: "Task Management App",
                description: "A productivity app for managing tasks and projects",
                image: "/placeholder.svg?height=300&width=400",
                tech: ["React", "Firebase", "Material UI"],
                demo: "#",
                github: "#",
              },
            ].map((project, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.1 * index }}
                className="bg-[#1e293b] rounded-lg overflow-hidden border border-[#38bdf8]/20 group"
              >
                <div className="h-48 relative overflow-hidden">
                  <Image
                    src={project.image || "/placeholder.svg"}
                    alt={project.title}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#0f172a] to-transparent opacity-60"></div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2 text-[#38bdf8]">{project.title}</h3>
                  <p className="text-gray-300 mb-4 text-sm">{project.description}</p>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tech.map((tech, i) => (
                      <span key={i} className="text-xs bg-[#38bdf8]/10 text-[#38bdf8] px-2 py-1 rounded-full">
                        {tech}
                      </span>
                    ))}
                  </div>

                  <div className="flex gap-3">
                    <Link
                      href={project.demo}
                      className="text-xs flex items-center gap-1 text-gray-300 hover:text-[#38bdf8] transition-colors"
                    >
                      <ExternalLink className="w-4 h-4" />
                      <span>Live Demo</span>
                    </Link>
                    <Link
                      href={project.github}
                      className="text-xs flex items-center gap-1 text-gray-300 hover:text-[#38bdf8] transition-colors"
                    >
                      <Github className="w-4 h-4" />
                      <span>GitHub</span>
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Link
              href="#"
              className="inline-block bg-[#38bdf8]/20 text-[#38bdf8] px-6 py-2 rounded-full text-sm font-medium hover:bg-[#38bdf8]/30 transition-all duration-300 border border-[#38bdf8]/30"
            >
              View All Projects
            </Link>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section ref={skillsRef} id="skills" className="py-20 px-4 min-h-screen flex items-center bg-black">
        <div className="max-w-6xl mx-auto w-full">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-16">
            <motion.h2
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-5xl font-bold text-white"
            >
              My
              <br />
              Skills
            </motion.h2>
          </div>

          {/* Languages & Frameworks */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="mb-16"
          >
            <h3 className="text-2xl font-semibold mb-8 text-center text-white">Languages & Frameworks</h3>
            <div className="bg-[#0a0a0a] border border-[#333] rounded-xl p-6">
              <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-7 lg:grid-cols-9 gap-6 justify-items-center">
                {[
                  { name: "Java", icon: "/skills/java.png", color: "#f89820" },
                  { name: "JavaScript", icon: "/skills/javascript.png", color: "#f7df1e" },
                  { name: "TypeScript", icon: "/skills/typescript.png", color: "#3178c6" },
                  { name: "C", icon: "/skills/c.svg", color: "#5c6bc0" },
                  { name: "C++", icon: "/skills/cpp.svg", color: "#00599c" },
                  { name: "Python", icon: "/skills/python.svg", color: "#3776ab" },
                  { name: "HTML5", icon: "/skills/html5.svg", color: "#e34f26" },
                  { name: "CSS3", icon: "/skills/css3.svg", color: "#1572b6" },
                  { name: "TailwindCSS", icon: "/skills/tailwindcss.png", color: "#38b2ac" },
                  { name: "React", icon: "/skills/react.png", color: "#61dafb" },
                  { name: "Next.js", icon: "/skills/nextjs.png", color: "#ffffff" },
                  { name: "Electron.js", icon: "/skills/electron.svg", color: "#47848f" },
                  { name: "Node.js", icon: "/skills/nodejs.png", color: "#339933" },
                  { name: "Express.js", icon: "/skills/express.svg", color: "#ffffff" },
                  { name: "Chart.js", icon: "/skills/chartjs.svg", color: "#ff6384" },
                ].map((skill, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: 0.05 * index }}
                    whileHover={{ y: -5, scale: 1.05 }}
                    className="flex flex-col items-center"
                  >
                    <div className="w-12 h-12 flex items-center justify-center bg-[#111] rounded-md p-2 mb-2 border border-[#333] shadow-[0_0_10px_rgba(255,255,255,0.1)]">
                      <div className="w-8 h-8 relative">
                        <Image src={skill.icon || "/placeholder.svg"} alt={skill.name} width={32} height={32} />
                      </div>
                    </div>
                    <span className="text-xs text-gray-300 text-center">{skill.name}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Databases & Tools */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h3 className="text-2xl font-semibold mb-8 text-center text-white">Databases & Tools</h3>
            <div className="bg-[#0a0a0a] border border-[#333] rounded-xl p-6">
              <div className="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-7 lg:grid-cols-9 gap-6 justify-items-center">
                {[
                  { name: "MySQL", icon: "/skills/mysql.png", color: "#4479a1" },
                  { name: "Postgres", icon: "/skills/postgres.svg", color: "#336791" },
                  { name: "Supabase", icon: "/skills/supabase.svg", color: "#3ecf8e" },
                  { name: "Prisma", icon: "/skills/prisma.svg", color: "#2d3748" },
                  { name: "Git", icon: "/skills/git.svg", color: "#f05032" },
                  { name: "GitHub", icon: "/skills/github.png", color: "#ffffff" },
                  { name: "AWSLambda", icon: "/skills/aws-lambda.svg", color: "#ff9900" },
                  { name: "Serverless", icon: "/skills/serverless.svg", color: "#fd5750" },
                  { name: "Postman", icon: "/skills/postman.svg", color: "#ff6c37" },
                  { name: "Linux", icon: "/skills/linux.svg", color: "#fcc624" },
                  { name: "NPM", icon: "/skills/npm.svg", color: "#cb3837" },
                  { name: "Vercel", icon: "/skills/vercel.png", color: "#ffffff" },
                  { name: "Langchain", icon: "/skills/langchain.svg", color: "#65c466" },
                  { name: "OpenAI", icon: "/skills/openai.svg", color: "#412991" },
                  { name: "Power BI", icon: "/skills/powerbi.svg", color: "#f2c811" },
                  { name: "VSCode", icon: "/skills/vscode.svg", color: "#007acc" },
                  { name: "IntelliJ IDEA", icon: "/skills/intellij.svg", color: "#000000" },
                  { name: "Colab", icon: "/skills/colab.svg", color: "#f9ab00" },
                  { name: "Figma", icon: "/skills/figma.svg", color: "#f24e1e" },
                  { name: "Notion", icon: "/skills/notion.svg", color: "#ffffff" },
                  { name: "Obsidian", icon: "/skills/obsidian.svg", color: "#7e6ad6" },
                  { name: "Jira", icon: "/skills/jira.svg", color: "#0052cc" },
                ].map((skill, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: 0.05 * index }}
                    whileHover={{ y: -5, scale: 1.05 }}
                    className="flex flex-col items-center"
                  >
                    <div className="w-12 h-12 flex items-center justify-center bg-[#111] rounded-md p-2 mb-2 border border-[#333] shadow-[0_0_10px_rgba(255,255,255,0.1)]">
                      <div className="w-8 h-8 relative">
                        <Image src={skill.icon || "/placeholder.svg"} alt={skill.name} width={32} height={32} />
                      </div>
                    </div>
                    <span className="text-xs text-gray-300 text-center">{skill.name}</span>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Education Section */}
      <section ref={educationRef} id="education" className="py-20 px-4 min-h-screen flex items-center bg-black">
        <div className="max-w-5xl mx-auto w-full">
          <motion.h2
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-4xl font-bold mb-16 text-white relative inline-block"
          >
            Education
            <span className="absolute -bottom-2 left-0 w-1/2 h-1 bg-[#38bdf8]"></span>
          </motion.h2>

          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-0 md:left-1/2 top-0 bottom-0 w-0.5 bg-gradient-to-b from-[#38bdf8] to-[#0ea5e9] transform md:translate-x-px"></div>

            <div className="space-y-12">
              {[
                {
                  degree: "B.Tech in Computer Science (Data Science)",
                  institution: "RCOEM, Nagpur",
                  duration: "2020 - 2024",
                  gpa: "9.2/10",
                  description: "Specialized in Data Science with a focus on machine learning and web development.",
                },
                {
                  degree: "Higher Secondary Education",
                  institution: "XYZ Junior College",
                  duration: "2018 - 2020",
                  gpa: "92%",
                  description: "Focused on Computer Science, Mathematics, and Physics.",
                },
                {
                  degree: "Secondary School Education",
                  institution: "ABC School",
                  duration: "2017 - 2018",
                  gpa: "95%",
                  description: "Received excellence award for academic performance.",
                },
              ].map((edu, index) => (
                <div key={index} className="relative">
                  {/* Timeline dot */}
                  <div className="absolute left-0 md:left-1/2 w-5 h-5 bg-[#38bdf8] rounded-full shadow-[0_0_10px_rgba(56,189,248,0.5)] transform -translate-x-1/2 z-10"></div>

                  <motion.div
                    initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: 0.1 * index }}
                    className={`md:w-1/2 ml-8 md:ml-0 ${index % 2 === 0 ? "md:pr-12" : "md:pl-12 md:ml-auto"}`}
                  >
                    <div className="bg-[#1e293b] p-6 rounded-lg border border-[#38bdf8]/20">
                      <h3 className="text-xl font-semibold text-[#38bdf8]">{edu.degree}</h3>
                      <div className="flex justify-between items-center mt-2 mb-4">
                        <span className="text-gray-300">{edu.institution}</span>
                        <span className="text-gray-400 text-sm">{edu.duration}</span>
                      </div>
                      <div className="inline-block bg-[#38bdf8]/10 text-[#38bdf8] px-3 py-1 rounded-full text-sm mb-4">
                        GPA: {edu.gpa}
                      </div>
                      <p className="text-gray-300 text-sm">{edu.description}</p>
                    </div>
                  </motion.div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section ref={contactRef} id="contact" className="py-20 px-4 min-h-screen flex items-center bg-black">
        <div className="max-w-5xl mx-auto w-full">
          <motion.h2
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-4xl font-bold mb-16 text-white relative inline-block"
          >
            Contact
            <span className="absolute -bottom-2 left-0 w-1/2 h-1 bg-[#38bdf8]"></span>
          </motion.h2>

          <div className="grid md:grid-cols-2 gap-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="space-y-6"
            >
              <h3 className="text-xl font-semibold text-[#38bdf8]">Get In Touch</h3>
              <p className="text-gray-300">
                Feel free to reach out to me for any inquiries, collaboration opportunities, or just to say hello!
              </p>

              <div className="space-y-4 mt-8">
                <div className="flex items-center gap-4">
                  <div className="bg-[#1e293b] p-3 rounded-full border border-[#38bdf8]/20">
                    <Mail className="w-5 h-5 text-[#38bdf8]" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-400">Email</h4>
                    <p className="text-gray-300">email@example.com</p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="bg-[#1e293b] p-3 rounded-full border border-[#38bdf8]/20">
                    <Linkedin className="w-5 h-5 text-[#38bdf8]" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-400">LinkedIn</h4>
                    <p className="text-gray-300">linkedin.com/in/username</p>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="bg-[#1e293b] p-3 rounded-full border border-[#38bdf8]/20">
                    <Github className="w-5 h-5 text-[#38bdf8]" />
                  </div>
                  <div>
                    <h4 className="text-sm font-medium text-gray-400">GitHub</h4>
                    <p className="text-gray-300">github.com/username</p>
                  </div>
                </div>
              </div>

              <div className="flex gap-4 mt-8">
                <Link
                  href="#"
                  className="bg-[#1e293b] p-3 rounded-full hover:bg-[#38bdf8]/20 transition-all duration-300 border border-[#38bdf8]/30"
                >
                  <Github className="w-5 h-5 text-[#38bdf8]" />
                </Link>
                <Link
                  href="#"
                  className="bg-[#1e293b] p-3 rounded-full hover:bg-[#38bdf8]/20 transition-all duration-300 border border-[#38bdf8]/30"
                >
                  <Mail className="w-5 h-5 text-[#38bdf8]" />
                </Link>
                <Link
                  href="#"
                  className="bg-[#1e293b] p-3 rounded-full hover:bg-[#38bdf8]/20 transition-all duration-300 border border-[#38bdf8]/30"
                >
                  <Linkedin className="w-5 h-5 text-[#38bdf8]" />
                </Link>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              <form className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm text-gray-400">
                      Name
                    </label>
                    <input
                      type="text"
                      id="name"
                      className="w-full bg-[#1e293b] border border-[#38bdf8]/20 rounded-lg p-3 text-white focus:outline-none focus:border-[#38bdf8]/50"
                      placeholder="Your Name"
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm text-gray-400">
                      Email
                    </label>
                    <input
                      type="email"
                      id="email"
                      className="w-full bg-[#1e293b] border border-[#38bdf8]/20 rounded-lg p-3 text-white focus:outline-none focus:border-[#38bdf8]/50"
                      placeholder="Your Email"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label htmlFor="subject" className="text-sm text-gray-400">
                    Subject
                  </label>
                  <input
                    type="text"
                    id="subject"
                    className="w-full bg-[#1e293b] border border-[#38bdf8]/20 rounded-lg p-3 text-white focus:outline-none focus:border-[#38bdf8]/50"
                    placeholder="Subject"
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="message" className="text-sm text-gray-400">
                    Message
                  </label>
                  <textarea
                    id="message"
                    rows={5}
                    className="w-full bg-[#1e293b] border border-[#38bdf8]/20 rounded-lg p-3 text-white focus:outline-none focus:border-[#38bdf8]/50"
                    placeholder="Your Message"
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="bg-[#38bdf8] text-[#0f172a] px-6 py-3 rounded-lg font-medium hover:bg-[#38bdf8]/90 transition-all duration-300 shadow-[0_0_15px_rgba(56,189,248,0.3)]"
                >
                  Send Message
                </button>
              </form>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 text-center text-gray-400 text-sm border-t border-[#38bdf8]/10 bg-black">
        <p>© {new Date().getFullYear()} Vedanti Udapure. All rights reserved.</p>
      </footer>
    </main>
  )
}
